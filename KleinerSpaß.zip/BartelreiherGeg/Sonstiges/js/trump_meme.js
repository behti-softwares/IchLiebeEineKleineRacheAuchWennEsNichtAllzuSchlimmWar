const blitz = document.getElementById("icon");
const trump_meme = document.getElementById("trump_meme");
const svg = document.getElementById("svg");

blitz.addEventListener("click", () => {
    svg.style.display = "none";
    trump_meme.style.display = "flex";
});
