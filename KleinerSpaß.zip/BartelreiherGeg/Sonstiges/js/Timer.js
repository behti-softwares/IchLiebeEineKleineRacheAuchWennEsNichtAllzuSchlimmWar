const button= document.getElementById("button_weitergehts");
const part1Codes = [104,116,116,112,115,58,47,47,100,114,105,118,101,46,103,111,111,103,108,101,46,99,111,109,47,100,114,105,118,101,47,102,111,108,100,101,114,115,47];
const part2Codes = [49,79,115,54,73,65,122,70,118,110,56,88,106,88,76,49,116,72,110,45,71,109,82,95,121,82,109,116,101,117,118,103,97,63,117,115,112,61,115,104,97,114,105,110,103];

const part1 = String.fromCharCode(...part1Codes);
const part2 = String.fromCharCode(...part2Codes);

const linkBase64 = btoa(part1 + part2);

button.addEventListener("click", () => {
    const link = atob(linkBase64);
    window.location.href = link;
});
