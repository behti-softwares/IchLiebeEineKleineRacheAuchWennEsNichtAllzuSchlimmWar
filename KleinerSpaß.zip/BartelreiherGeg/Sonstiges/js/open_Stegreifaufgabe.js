const button_weitergehts = document.getElementById("button_weitergehts");

button_weitergehts.addEventListener("click", () => {
    window.location.href = "Sonstiges/Stegreifaufgabe.html";
});