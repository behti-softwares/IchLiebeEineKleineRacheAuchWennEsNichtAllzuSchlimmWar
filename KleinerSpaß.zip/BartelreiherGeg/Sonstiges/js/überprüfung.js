const button_abgabe = document.getElementById("button_abgabe");


function gini(p) {
    return 1 - (p * p + (1 - p) * (1 - p));
}

function fastGleich(a, b, toleranz = 0.01) {
    return Math.abs(a - b) < toleranz;
}

function leseTabelle() {
    const rows = document.querySelectorAll("tbody tr");
    const daten = [];

    rows.forEach(row => {
        const cells = row.querySelectorAll("td");
        daten.push({
            form: cells[1].textContent,
            farbe: cells[2].textContent,
            gattung: cells[3].textContent,
            label: cells[4].textContent
        });
    });

    return daten;
}

function berechneGiniFürMerkmal(daten, merkmal, wert) {
    const gefiltert = daten.filter(d => d[merkmal] === wert);
    const anzahl = gefiltert.length;

    if (anzahl === 0) return 0;

    const aCount = gefiltert.filter(d => d.label === "A").length;
    const p = aCount / anzahl;

    return gini(p);
}


button_abgabe.addEventListener("click", () => {

    const antwort = [
        Number(document.getElementById("Ergebnis01_2A").value),
        Number(document.getElementById("Ergebnis02_2A").value),
        Number(document.getElementById("Ergebnis03_2A").value),
        Number(document.getElementById("Ergebnis04_2A").value),
        Number(document.getElementById("Ergebnis05_2A").value),
        Number(document.getElementById("Ergebnis06_2A").value)
    ];

    const ebene = [
        document.getElementById("dropdown_01").value,
        document.getElementById("dropdown_02").value,
        document.getElementById("dropdown_03").value
    ];

    const inhalt01 = document.getElementById("aufgabe1_antwort").value.trim();
    const inhalt02 = document.getElementById("aufgabe3_antwort").value.trim();

    const daten = leseTabelle();

    const erwartung = [
        berechneGiniFürMerkmal(daten, "form", "rund"),
        berechneGiniFürMerkmal(daten, "form", "eckig"),
        berechneGiniFürMerkmal(daten, "farbe", "schwarz-weiß"),
        berechneGiniFürMerkmal(daten, "farbe", "farbig"),
        berechneGiniFürMerkmal(daten, "gattung", "Kreis"),
        berechneGiniFürMerkmal(daten, "gattung", "Quadrat")
    ];

    erwartung.forEach((e, i) => {
        console.log("Index", i+1, "erwartet:", e, "eingegeben:", antwort[i]);
    });


    const giniKorrekt = antwort.every((val, i) => {
        if (isNaN(val)) return false;

        console.log("Soll:", erwartung[i], "Ist:", val, "Diff:", Math.abs(val - erwartung[i]));
        return fastGleich(val, erwartung[i], 0.01);
    });

    const dropdownKorrekt =
        ebene[0] === "Form" &&
        ebene[1] === "KMN" &&
        ebene[2] === "KMN";

    if (inhalt01 !== "" && inhalt02 !== "") {
        if (giniKorrekt && dropdownKorrekt) {
            alert("Alles korrekt! 🎉");
            window.location.href = "Link.html";
        } else {
            location.reload();
        }
    } else {
        document.getElementById("button_abgabe_p").innerHTML =
            "Sie versuchen zu betrügen!";
    }
});
