document.getElementById("button_start").addEventListener("click", () => {
    // Header ausblenden, Aufgaben einblenden
    document.getElementById("header").style.display = "none";
    document.getElementById("aufgaben_ground").style.display = "flex";

    // Timer starten: 20 Minuten = 20 * 60 * 1000 ms = 1.200.000 ms
    setTimeout(() => {
        alert("Zeit abgelaufen! Die Seite wird neu geladen.");
        location.reload();
    }, 20 * 60 * 1000); // 20 Minuten
});
