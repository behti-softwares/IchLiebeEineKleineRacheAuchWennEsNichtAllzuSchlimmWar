const datumParagraph = document.getElementById("aufgaben_datum");

const heute = new Date();

const datumString = heute.getDate() + "." + (heute.getMonth() + 1) + "." + heute.getFullYear();

datumParagraph.innerHTML = "am " + datumString;
